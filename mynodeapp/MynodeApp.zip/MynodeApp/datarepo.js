var itemlist=[
    {
    "itemname":"Coffee",
    "price":20,
    "quantity":10
},{
    "itemname":"Esproc",
    "price":30,
    "quantity":10
},{
    "itemname":"Ice tea",
    "price":25,
    "quantity":35
}
]

export default {data:itemlist}