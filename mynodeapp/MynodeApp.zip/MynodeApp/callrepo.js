var calldropreport=[
    {
    "callnumber":"9933434343",
    "call_duration_in_minutes":3,
    "call_drop":"true"
    },
 {
    "callnumber":"64783879843",
    "call_duration_in_minutes":5,
    "call_drop":"false"

 },
 {
    "callnumber":"89898998875",
    "call_duration_in_minutes":5,
    "call_drop":"false"

 }
]

export default {data:calldropreport}